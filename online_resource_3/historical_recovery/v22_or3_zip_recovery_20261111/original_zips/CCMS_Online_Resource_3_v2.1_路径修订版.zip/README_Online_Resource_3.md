# Online Resource 3 — 20,000-draw conditional bootstrap reanalysis

This resource extends the primary APS C/B/M3 conditional bootstrap analysis from 1,000 to 20,000 paired, class-stratified row-weight replicates using the archived per-sample predictions in Online Resource 2 (`ESM_2.zip`). It does **not** retrain models, regenerate training masks, or repeat model selection.

## Files

- `reproduce_bootstrap_20k.py`: reproduction script.
- `r13_threeway_20k.json`: point estimates, 20,000-draw intervals, reconciliation checks and source metadata.
- `aps_threeway_draws_20k.npz`: bootstrap draw matrices for C-B, C-M3 and B-M3 across validation/test and S0/S1_30/S2/S3.
- `CCMS_20k_bootstrap_summary.json`: nominal, Bonferroni, sup-t and Holm summary used for Table 5.
- `01_three_way_decomposition_20k.png` / `.pdf`: Figure 1 using the 20,000-draw intervals.

## Reproduction

Extract `ESM_2.zip`. The ZIP contains a top-level `ESM_2/` directory. Set `ESM_ROOT` to that extracted `ESM_2` directory, which must directly contain:

`08_repro_bundle/02_本轮代码与结果/results/`

Then run:

```bash
ESM_ROOT=/path/to/ESM_2 \
CCMS_OUT=/path/to/output \
CCMS_NBOOT=20000 \
python3 reproduce_bootstrap_20k.py
```

Requirements: Python 3.10+, NumPy and scikit-learn. Matplotlib is needed only if Figure 1 is regenerated; the bootstrap script itself uses NumPy and scikit-learn.

The script checks that point estimates and the first 1,000 C-B bootstrap draws match the archived values; intervals are re-estimated using all 20,000 draws.

## Source-path metadata

In the original JSON, source paths included an obsolete nested directory component. The source-file SHA-256 values matched the corresponding files in the current `ESM_2.zip`, but the paths were not directly resolvable from the documented `ESM_ROOT`. This reconciled version rewrites those paths relative to the actual `ESM_2` root; it does not alter the source bytes, bootstrap draws, point estimates or interval values.

## Interpretation boundary

The additional 19,000 draws reduce Monte Carlo error in conditional bootstrap intervals. They do not address model-training, training-mask resampling, or selection uncertainty. A3/A4 path-decomposition intervals and fixed-alert-budget decision intervals remain based on their archived 1,000-draw analyses and are reported separately. Supplementary model configurations remain descriptive summaries and are not assigned new bootstrap intervals.
